'use client'

import React, { useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import Papa from "papaparse";

// =====================================================
// Phoenix Sawing Operations Dashboard (stable build)
// - Manual Unassign + Add operator per machine
// - Headcount cap & "1 operator can run 2 band saws" logic
// - Lunch break + carry-over to next shift + planning date
// - CSV import/export, SFM capability-aware scheduling
// =====================================================

export type Shift = "A" | "B" | "C";
export type Strategy = "changeover" | "material" | "size" | "due" | "priority";

// ---------- Types ----------
interface Machine {
  id: string;
  name: string;
  department: string;
  bladeSize: string; // e.g. 1.25" Bi-metal, 2.0" Carbide, Shear
  requiredSafety: string[];
  requiredTraining: string[];
  headcountByShift: Record<Shift, number>;
  materials: string[]; // supported materials
  thicknessMin: number;
  thicknessMax: number;
  speedIps: number; // fallback inches/sec
  minBladeSFM?: number;
  maxBladeSFM?: number;
}

interface Order {
  id: string;
  customer: string;
  material: string; // Steel/Aluminum/Stainless/Brass/Plate Steel
  thickness: number; // in (dia for round)
  lengthInches: number; // in
  qty: number;
  dueDate: string; // ISO
  priority: number; // 1 (highest) .. 5
}

interface ScheduledOrder extends Order {
  machineId: string;
  shift: Shift;
  estimatedSeconds: number;
  sequenceIndex: number;
  startISO?: string;
  endISO?: string;
}

interface CutStandard {
  bladeSize: string;
  material: string;
  thicknessMin: number;
  thicknessMax: number;
  feedRateInPerMin: number; // linear inches/min
  note?: string;
}

interface BladeSpeedStandard {
  bladeType: string;
  material: string;
  thicknessMin: number;
  thicknessMax: number;
  sfmMin: number;
  sfmMax: number;
  note?: string;
}

interface Employee {
  id: string;
  name: string;
  shift: Shift; // home shift
  lockedShift?: Shift; // if set, only assignable on this shift
  certifications: string[]; // e.g., PPE, Forklift
  certExpirations?: Record<string, string>; // ISO dates per cert
  training: string[]; // e.g., Saw Basics, Plate Handling
  canOperate?: string[]; // explicit machine IDs this person can run
  maxMachinesPerDay?: number;
}

// ---------- Machines (real list) ----------
const sideLoaders: Machine[] = Array.from({ length: 7 }, (_, i) => ({
  id: `SL009-${i + 1}`,
  name: `SIDE LOADER #${i + 1}`,
  department: "Support",
  bladeSize: "Shear",
  requiredSafety: ["PPE"],
  requiredTraining: [],
  headcountByShift: { A: 0, B: 0, C: 0 },
  materials: [],
  thicknessMin: 0,
  thicknessMax: 0,
  speedIps: 0,
}));

const REAL_MACHINES: Machine[] = [
  { id: "BS001", name: "H-12 BAND SAW", department: "Cutting", bladeSize: "1.25\\" Bi-metal", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel", "Aluminum", "Stainless", "Brass"], thicknessMin: 0.25, thicknessMax: 6, speedIps: 1.8, minBladeSFM: 50, maxBladeSFM: 5000 },
  { id: "BS001-DM12", name: "DM12 BAND SAW", department: "Cutting", bladeSize: "1.25\\" Bi-metal", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel", "Aluminum", "Stainless", "Brass"], thicknessMin: 0.25, thicknessMax: 6, speedIps: 1.8, minBladeSFM: 50, maxBladeSFM: 5000 },
  { id: "BS001-H18", name: "H18 BAND SAW", department: "Cutting", bladeSize: "1.25\\" Bi-metal", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel", "Aluminum", "Stainless", "Brass"], thicknessMin: 0.25, thicknessMax: 7, speedIps: 1.8, minBladeSFM: 50, maxBladeSFM: 5000 },
  { id: "BS001-H22", name: "H22 BAND SAW", department: "Cutting", bladeSize: "1.25\\" Bi-metal", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel", "Aluminum", "Stainless", "Brass"], thicknessMin: 0.25, thicknessMax: 8, speedIps: 1.8, minBladeSFM: 50, maxBladeSFM: 5000 },
  { id: "BS001-M20", name: "M20 BAND SAW", department: "Cutting", bladeSize: "1.25\\" Bi-metal", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel", "Aluminum", "Stainless", "Brass"], thicknessMin: 0.25, thicknessMax: 10, speedIps: 1.8, minBladeSFM: 50, maxBladeSFM: 5000 },
  { id: "BS002", name: "BUNDLE SPLITTER", department: "Cutting", bladeSize: "1.25\\" Bi-metal", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel", "Aluminum"], thicknessMin: 0.25, thicknessMax: 6, speedIps: 1.5, minBladeSFM: 50, maxBladeSFM: 5000 },
  { id: "CH001", name: "ABRASIVE SAW", department: "Cutting", bladeSize: "Abrasive", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel"], thicknessMin: 0.25, thicknessMax: 3, speedIps: 2.0 },
  { id: "CH001-ALUM", name: "ALUM CHOP SAW", department: "Cutting", bladeSize: "Carbide", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Aluminum", "Brass"], thicknessMin: 0.125, thicknessMax: 6, speedIps: 3.0, minBladeSFM: 200, maxBladeSFM: 6000 },
  { id: "CM001", name: "BAR SAW", department: "Cutting", bladeSize: "1.25\\" Bi-metal", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel", "Aluminum", "Stainless", "Brass"], thicknessMin: 0.5, thicknessMax: 10, speedIps: 1.6, minBladeSFM: 50, maxBladeSFM: 5000 },
  { id: "CS002", name: "CIRCLE SAW", department: "Cutting", bladeSize: "Carbide", requiredSafety: ["PPE"], requiredTraining: ["Saw Basics"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Aluminum", "Brass"], thicknessMin: 0.25, thicknessMax: 6, speedIps: 2.5, minBladeSFM: 200, maxBladeSFM: 6000 },
  { id: "PS001-1", name: "PLATE SAW #1", department: "Plate", bladeSize: "2.0\\" Carbide", requiredSafety: ["PPE"], requiredTraining: ["Plate Handling"], headcountByShift: { A: 2, B: 1, C: 0 }, materials: ["Plate Steel", "Steel", "Aluminum"], thicknessMin: 0.25, thicknessMax: 20, speedIps: 0.8, minBladeSFM: 100, maxBladeSFM: 6000 },
  { id: "PS001-2", name: "PLATE SAW #2", department: "Plate", bladeSize: "2.0\\" Carbide", requiredSafety: ["PPE"], requiredTraining: ["Plate Handling"], headcountByShift: { A: 2, B: 1, C: 0 }, materials: ["Plate Steel", "Steel", "Aluminum"], thicknessMin: 0.25, thicknessMax: 20, speedIps: 0.8, minBladeSFM: 100, maxBladeSFM: 6000 },
  { id: "PS002", name: "PANNING STATION", department: "Other", bladeSize: "Shear", requiredSafety: [], requiredTraining: [], headcountByShift: { A: 1, B: 1, C: 0 }, materials: [], thicknessMin: 0, thicknessMax: 0, speedIps: 0 },
  { id: "PV001", name: "PVC MACHINE", department: "Other", bladeSize: "Abrasive", requiredSafety: [], requiredTraining: [], headcountByShift: { A: 1, B: 1, C: 0 }, materials: [], thicknessMin: 0, thicknessMax: 0, speedIps: 0 },
  { id: "SH001-ACC", name: "ACCUR SHEAR", department: "Shear", bladeSize: "Shear", requiredSafety: ["PPE"], requiredTraining: ["Shear Handling"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel"], thicknessMin: 0.125, thicknessMax: 1, speedIps: 3.0 },
  { id: "SH001-CIN-12", name: "CINCINATTI SHEAR 1/2\\"", department: "Shear", bladeSize: "Shear", requiredSafety: ["PPE"], requiredTraining: ["Shear Handling"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel"], thicknessMin: 0.125, thicknessMax: 0.5, speedIps: 3.0 },
  { id: "SH001-CIN-14", name: "CINCINATTI SHEAR 1/4\\"", department: "Shear", bladeSize: "Shear", requiredSafety: ["PPE"], requiredTraining: ["Shear Handling"], headcountByShift: { A: 1, B: 1, C: 0 }, materials: ["Steel"], thicknessMin: 0.0625, thicknessMax: 0.25, speedIps: 3.0 },
  { id: "SL006", name: "SCISSOR LIFT", department: "Support", bladeSize: "Shear", requiredSafety: ["PPE"], requiredTraining: [], headcountByShift: { A: 0, B: 0, C: 0 }, materials: [], thicknessMin: 0, thicknessMax: 0, speedIps: 0 },
  ...sideLoaders,
];

// ---------- Starter Employees with locked shift & expirations ----------
const STARTER_EMPLOYEES: Employee[] = [
  { id: "E001", name: "Alejandro Agulair", shift: "A", lockedShift: "A", certifications: ["PPE"], certExpirations: { PPE: "2026-01-31" }, training: ["Shear Handling"], canOperate: ["SH001-ACC","SH001-CIN-12","SH001-CIN-14"], maxMachinesPerDay: 1 },
  { id: "E002", name: "Anthony Hernandez", shift: "A", lockedShift: "A", certifications: ["PPE","Forklift"], certExpirations: { PPE: "2025-11-01", Forklift: "2026-06-30" }, training: ["Saw Basics","Leadership"], canOperate: ["BS001","BS001-DM12","BS001-H18","BS001-H22","BS001-M20","BS002","CM001"], maxMachinesPerDay: 1 },
  { id: "E003", name: "Christina Middleton", shift: "A", certifications: ["PPE"], certExpirations: { PPE: "2026-03-31" }, training: ["Router"], canOperate: [], maxMachinesPerDay: 1 },
  { id: "E004", name: "Davon Pope", shift: "A", lockedShift: "A", certifications: ["PPE","Forklift"], certExpirations: { PPE: "2026-02-28", Forklift: "2026-01-15" }, training: ["Saw Basics"], canOperate: ["BS001","BS001-DM12","BS001-H18","BS001-H22","BS001-M20","BS002","CM001"], maxMachinesPerDay: 1 },
  { id: "E007", name: "Jacob Rowland", shift: "A", lockedShift: "A", certifications: ["PPE","Forklift"], certExpirations: { PPE: "2026-05-31", Forklift: "2025-12-31" }, training: ["Plate Handling"], canOperate: ["PS001-1","PS001-2"], maxMachinesPerDay: 1 },
  { id: "E009", name: "Joseph Lara", shift: "A", lockedShift: "A", certifications: ["PPE","Forklift"], certExpirations: { PPE: "2026-05-31", Forklift: "2025-12-31" }, training: ["Plate Handling"], canOperate: ["PS001-1","PS001-2"], maxMachinesPerDay: 1 },
  { id: "E010", name: "Joseph Leimeister", shift: "A", lockedShift: "A", certifications: ["PPE","Forklift"], certExpirations: { PPE: "2026-02-28", Forklift: "2026-07-30" }, training: ["Saw Basics"], canOperate: ["BS001","BS001-DM12","BS001-H18","BS001-H22","BS001-M20","BS002","CM001"], maxMachinesPerDay: 1 },
  { id: "E012", name: "Michael Avita", shift: "A", lockedShift: "A", certifications: ["PPE","Forklift"], certExpirations: { PPE: "2026-03-31", Forklift: "2026-03-01" }, training: ["Saw Basics"], canOperate: ["BS001","BS001-DM12","BS001-H18","BS001-H22","BS001-M20","BS002","CM001"], maxMachinesPerDay: 1 },
  { id: "E013", name: "Nicholos Matsueda", shift: "A", lockedShift: "A", certifications: ["PPE"], certExpirations: { PPE: "2025-12-31" }, training: ["Shear Handling"], canOperate: ["SH001-ACC","SH001-CIN-12","SH001-CIN-14"], maxMachinesPerDay: 1 },
  { id: "E014", name: "Patrick Allen", shift: "A", certifications: ["PPE","Forklift"], certExpirations: { PPE: "2026-04-30", Forklift: "2026-04-30" }, training: ["Plate Handling"], canOperate: ["PS001-1","PS001-2"], maxMachinesPerDay: 1 },
  { id: "E016", name: "Taylor Stegman", shift: "A", lockedShift: "A", certifications: ["PPE"], certExpirations: { PPE: "2026-01-31" }, training: ["Shear Handling"], canOperate: ["SH001-ACC","SH001-CIN-12","SH001-CIN-14"], maxMachinesPerDay: 1 },
];

// ---------- Starter Standards ----------
const STARTER_STANDARDS: CutStandard[] = [
  { bladeSize: '1.25" Bi-metal', material: 'Steel', thicknessMin: 0.25, thicknessMax: 2.0, feedRateInPerMin: 7 },
  { bladeSize: '1.25" Bi-metal', material: 'Steel', thicknessMin: 2.01, thicknessMax: 6.0, feedRateInPerMin: 4.5 },
  { bladeSize: '1.25" Bi-metal', material: 'Stainless', thicknessMin: 0.25, thicknessMax: 6.0, feedRateInPerMin: 3.5 },
  { bladeSize: '1.25" Bi-metal', material: 'Aluminum', thicknessMin: 0.25, thicknessMax: 6.0, feedRateInPerMin: 18 },
  { bladeSize: '2.0" Carbide', material: 'Steel', thicknessMin: 0.5, thicknessMax: 8.0, feedRateInPerMin: 6 },
  { bladeSize: '2.0" Carbide', material: 'Aluminum', thicknessMin: 0.5, thicknessMax: 12.0, feedRateInPerMin: 40 },
  { bladeSize: '2.0" Carbide', material: 'Stainless', thicknessMin: 0.5, thicknessMax: 8.0, feedRateInPerMin: 5 },
  { bladeSize: 'Abrasive', material: 'Steel', thicknessMin: 0.25, thicknessMax: 3.0, feedRateInPerMin: 8 },
  { bladeSize: 'Carbide', material: 'Aluminum', thicknessMin: 0.125, thicknessMax: 6.0, feedRateInPerMin: 40 },
  { bladeSize: 'Shear', material: 'Steel', thicknessMin: 0.125, thicknessMax: 0.25, feedRateInPerMin: 120, note: 'Near-instant' },
  { bladeSize: 'Shear', material: 'Steel', thicknessMin: 0.26, thicknessMax: 0.5, feedRateInPerMin: 90 },
  { bladeSize: 'Shear', material: 'Steel', thicknessMin: 0.51, thicknessMax: 1.0, feedRateInPerMin: 60 },
];

const STARTER_BLADE_SPEEDS: BladeSpeedStandard[] = [
  { bladeType: '1.25" Bi-metal', material: 'Steel', thicknessMin: 0, thicknessMax: 2, sfmMin: 200, sfmMax: 300, note: 'Carbon steel bar' },
  { bladeType: '1.25" Bi-metal', material: 'Steel', thicknessMin: 2, thicknessMax: 6, sfmMin: 150, sfmMax: 250 },
  { bladeType: '1.25" Bi-metal', material: 'Stainless', thicknessMin: 0, thicknessMax: 6, sfmMin: 120, sfmMax: 200 },
  { bladeType: '1.25" Bi-metal', material: 'Aluminum', thicknessMin: 0, thicknessMax: 6, sfmMin: 800, sfmMax: 1500 },
  { bladeType: '2.0" Carbide', material: 'Steel', thicknessMin: 0, thicknessMax: 8, sfmMin: 250, sfmMax: 400 },
  { bladeType: '2.0" Carbide', material: 'Aluminum', thicknessMin: 0, thicknessMax: 12, sfmMin: 1200, sfmMax: 3000 },
  { bladeType: '2.0" Carbide', material: 'Stainless', thicknessMin: 0, thicknessMax: 8, sfmMin: 200, sfmMax: 300 },
];

// ---------- Helpers ----------
function lookupFeedRate(bladeSize: string, material: string, thickness: number, standards: CutStandard[]) {
  const row = standards.find(
    s => s.bladeSize === bladeSize && s.material.toLowerCase() === material.toLowerCase() && thickness >= s.thicknessMin && thickness <= s.thicknessMax
  );
  return row ? row.feedRateInPerMin : null;
}

function estimateSeconds(o: Order, m: Machine, standards: CutStandard[]) {
  const fr = lookupFeedRate(m.bladeSize, o.material, o.thickness, standards);
  const ips = fr ? fr / 60 : Math.max(0.1, m.speedIps);
  const setup = 300; // 5 min
  return Math.round((o.lengthInches / ips) * o.qty + setup);
}

function eligibleMachines(o: Order, machines: Machine[]) {
  return machines.filter(
    m => m.materials.some(mat => mat.toLowerCase().includes(o.material.toLowerCase())) && o.thickness >= m.thicknessMin && o.thickness <= m.thicknessMax
  );
}

function formatSeconds(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h}h ${m}m`;
}
function formatTimeLocal(iso?: string) {
  if (!iso) return "—";
  const d = new Date(iso);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

function lookupBladeSfmRange(blade: string, material: string, thickness: number, table: BladeSpeedStandard[]) {
  const rows = table.filter(
    r => r.bladeType === blade && r.material.toLowerCase() === material.toLowerCase() && thickness >= r.thicknessMin && thickness <= r.thicknessMax
  );
  if (!rows.length) return null;
  return { sfmMin: Math.min(...rows.map(r => r.sfmMin)), sfmMax: Math.max(...rows.map(r => r.sfmMax)) };
}

function machineSfmCapable(m: Machine, o: Order, table: BladeSpeedStandard[]) {
  const r = lookupBladeSfmRange(m.bladeSize, o.material, o.thickness, table);
  if (!r) return true;
  const lo = m.minBladeSFM ?? -Infinity, hi = m.maxBladeSFM ?? Infinity;
  return r.sfmMin >= lo && r.sfmMax <= hi;
}

// Identify band saws for double-coverage rule (SINGLE DEFINITION)
function isBandSaw(m: Machine) {
  const n = m.name.toLowerCase();
  return m.id.startsWith('BS') || n.includes('band saw') || n.includes('bar saw');
}

function isCertValid(e: Employee, cert: string, todayISO: string) {
  const exp = e.certExpirations?.[cert];
  if (!exp) return true;
  return new Date(exp).getTime() >= new Date(todayISO).getTime();
}

function isQualified(e: Employee, m: Machine, todayISO: string): boolean {
  const safe = m.requiredSafety.every(s => e.certifications.includes(s) && isCertValid(e, s, todayISO));
  const trained = m.requiredTraining.every(t => e.training.includes(t));
  const listOK = !e.canOperate || e.canOperate.includes(m.id);
  return safe && trained && listOK;
}

// Auto-assign with bandsaw double-coverage & exclusivity elsewhere
function autoAssignWorkforce(machines: Machine[], employees: Employee[], shift: Shift, todayISO: string) {
  const available = employees.filter(e => (e.lockedShift ? e.lockedShift === shift : e.shift === shift));
  const bandCount: Record<string, number> = {};
  const nonBandCount: Record<string, number> = {};
  const assigned: Record<string, string[]> = {};
  for (const m of machines) {
    const need = m.headcountByShift[shift] || 0;
    if (!need) { assigned[m.id] = []; continue; }
    const pool = available.filter(e => {
      if (!isQualified(e, m, todayISO)) return false;
      const b = bandCount[e.id] || 0;
      const nb = nonBandCount[e.id] || 0;
      if (isBandSaw(m)) {
        // up to 2 band saws IF not already on any non-band
        return nb === 0 && b < 2;
      } else {
        // non-band consumes exclusivity
        return b === 0 && nb === 0;
      }
    });
    assigned[m.id] = [];
    for (const e of pool) {
      if (assigned[m.id].length >= need) break;
      assigned[m.id].push(e.id);
      if (isBandSaw(m)) bandCount[e.id] = (bandCount[e.id]||0) + 1; else nonBandCount[e.id] = (nonBandCount[e.id]||0) + 1;
    }
  }
  return assigned;
}

function planOrders(
  orders: Order[], machines: Machine[], standards: CutStandard[], shift: Shift, strategy: Strategy, bladeSpeeds?: BladeSpeedStandard[], autoSfmReschedule = true
): ScheduledOrder[] {
  const expanded: ScheduledOrder[] = [];
  for (const o of orders) {
    let cands = eligibleMachines(o, machines);
    if (!cands.length) continue;
    if (autoSfmReschedule && bladeSpeeds) {
      const ok = cands.filter(m => machineSfmCapable(m, o, bladeSpeeds));
      if (ok.length) cands = ok;
    }
    let best: Machine | null = null;
    let bestSec = Infinity;
    for (const m of cands) {
      const sec = estimateSeconds(o, m, standards);
      if (sec < bestSec) { bestSec = sec; best = m; }
    }
    const use = best || cands[0];
    expanded.push({ ...o, machineId: use.id, shift, estimatedSeconds: estimateSeconds(o, use, standards), sequenceIndex: 0 });
  }
  const sorter: Record<Strategy, (a: ScheduledOrder, b: ScheduledOrder) => number> = {
    changeover: (a,b)=> a.material.localeCompare(b.material)||a.thickness-b.thickness||a.priority-b.priority||new Date(a.dueDate).getTime()-new Date(b.dueDate).getTime(),
    material:  (a,b)=> a.material.localeCompare(b.material)||new Date(a.dueDate).getTime()-new Date(b.dueDate).getTime()||a.priority-b.priority||a.thickness-b.thickness,
    size:      (a,b)=> a.thickness-b.thickness||a.material.localeCompare(b.material)||new Date(a.dueDate).getTime()-new Date(b.dueDate).getTime()||a.priority-b.priority,
    due:       (a,b)=> new Date(a.dueDate).getTime()-new Date(b.dueDate).getTime()||a.priority-b.priority||a.material.localeCompare(b.material)||a.thickness-b.thickness,
    priority:  (a,b)=> a.priority-b.priority||new Date(a.dueDate).getTime()-new Date(b.dueDate).getTime()||a.material.localeCompare(b.material)||a.thickness-b.thickness,
  };
  const byM: Record<string, ScheduledOrder[]> = {};
  for (const s of expanded) (byM[s.machineId] ||= []).push(s);
  const out: ScheduledOrder[] = [];
  Object.values(byM).forEach(arr=>{ arr.sort(sorter[strategy]); arr.forEach((o,i)=>o.sequenceIndex=i+1); out.push(...arr); });
  return out;
}

// ---------- Shift timing with lunch + carry-over ----------
const DEFAULT_SHIFT_CONFIG: Record<Shift, {
  startHour: number; startMin: number; durationMin: number;
  lunchStartHour: number; lunchStartMin: number; lunchMinutes: number;
}> = {
  A: { startHour: 8,  startMin: 0, durationMin: 480, lunchStartHour: 12, lunchStartMin: 0, lunchMinutes: 30 },
  B: { startHour: 16, startMin: 0, durationMin: 480, lunchStartHour: 20, lunchStartMin: 0, lunchMinutes: 30 },
  C: { startHour: 0,  startMin: 0, durationMin: 480, lunchStartHour: 4,  lunchStartMin: 0, lunchMinutes: 30 },
};

function nextShift(s: Shift): Shift { return s === 'A' ? 'B' : s === 'B' ? 'C' : 'A'; }

function addStartFinishTimes(
  scheduled: ScheduledOrder[],
  shift: Shift,
  dayISO: string,
  cfg: typeof DEFAULT_SHIFT_CONFIG,
  clipToShift: boolean,
  carryToNextShift: boolean
): ScheduledOrder[] {
  const conf = cfg[shift];
  const startOfShift = new Date(`${dayISO}T00:00:00`);
  startOfShift.setHours(conf.startHour, conf.startMin, 0, 0);
  const endOfShift = new Date(startOfShift.getTime() + conf.durationMin * 60000);
  const lunchStart = new Date(startOfShift);
  lunchStart.setHours(conf.lunchStartHour, conf.lunchStartMin, 0, 0);
  const lunchEnd = new Date(lunchStart.getTime() + conf.lunchMinutes * 60000);

  const grouped: Record<string, ScheduledOrder[]> = {};
  for (const s of scheduled) (grouped[s.machineId] ||= []).push(s);
  const out: ScheduledOrder[] = [];

  for (const arr of Object.values(grouped)) {
    arr.sort((a,b)=>a.sequenceIndex-b.sequenceIndex);

    let cursor = new Date(startOfShift);
    let curShift = shift;
    let curStartOfShift = new Date(startOfShift);
    let curEndOfShift = new Date(endOfShift);
    let curLunchStart = new Date(lunchStart);
    let curLunchEnd = new Date(lunchEnd);

    for (const job of arr) {
      if (cursor >= curLunchStart && cursor < curLunchEnd) cursor = new Date(curLunchEnd);
      let tentativeEnd = new Date(cursor.getTime() + job.estimatedSeconds * 1000);
      if (cursor < curLunchStart && tentativeEnd > curLunchStart) {
        cursor = new Date(curLunchEnd);
        tentativeEnd = new Date(cursor.getTime() + job.estimatedSeconds * 1000);
      }

      if (clipToShift && tentativeEnd > curEndOfShift) {
        if (carryToNextShift) {
          const ns = nextShift(curShift);
          const nextStart = new Date(curStartOfShift);
          if (curShift === 'C') nextStart.setDate(nextStart.getDate() + 1);
          const ncfg = cfg[ns];
          nextStart.setHours(ncfg.startHour, ncfg.startMin, 0, 0);
          const nextEnd = new Date(nextStart.getTime() + ncfg.durationMin * 60000);
          const nLunchStart = new Date(nextStart); nLunchStart.setHours(ncfg.lunchStartHour, ncfg.lunchStartMin, 0, 0);
          const nLunchEnd = new Date(nLunchStart.getTime() + ncfg.lunchMinutes * 60000);
          curShift = ns; curStartOfShift = nextStart; curEndOfShift = nextEnd; curLunchStart = nLunchStart; curLunchEnd = nLunchEnd;
          cursor = new Date(curStartOfShift);
          if (cursor >= curLunchStart && cursor < curLunchEnd) cursor = new Date(curLunchEnd);
          tentativeEnd = new Date(cursor.getTime() + job.estimatedSeconds * 1000);
          if (cursor < curLunchStart && tentativeEnd > curLunchStart) {
            cursor = new Date(curLunchEnd);
            tentativeEnd = new Date(cursor.getTime() + job.estimatedSeconds * 1000);
          }
        } else {
          const nextDayStart = new Date(curStartOfShift);
          nextDayStart.setDate(nextDayStart.getDate() + 1);
          nextDayStart.setHours(conf.startHour, conf.startMin, 0, 0);
          const nextDayEnd = new Date(nextDayStart.getTime() + conf.durationMin * 60000);
          const nLunchStart = new Date(nextDayStart); nLunchStart.setHours(conf.lunchStartHour, conf.lunchStartMin, 0, 0);
          const nLunchEnd = new Date(nLunchStart.getTime() + conf.lunchMinutes * 60000);
          curStartOfShift = nextDayStart; curEndOfShift = nextDayEnd; curLunchStart = nLunchStart; curLunchEnd = nLunchEnd;
          cursor = new Date(nextDayStart);
          if (cursor >= curLunchStart && cursor < curLunchEnd) cursor = new Date(curLunchEnd);
          tentativeEnd = new Date(cursor.getTime() + job.estimatedSeconds * 1000);
          if (cursor < curLunchStart && tentativeEnd > curLunchStart) {
            cursor = new Date(curLunchEnd);
            tentativeEnd = new Date(cursor.getTime() + job.estimatedSeconds * 1000);
          }
        }
      }

      const start = new Date(cursor);
      const end = new Date(tentativeEnd);
      out.push({ ...job, startISO: start.toISOString(), endISO: end.toISOString() });
      cursor = end;
    }
  }
  return out.sort((a,b)=> a.machineId.localeCompare(b.machineId) || a.sequenceIndex - b.sequenceIndex);
}

// ---------- CSV helpers ----------
const ORDERS_CSV_TEMPLATE = `id,customer,material,thickness,lengthInches,qty,dueDate,priority\nSO-2001,Acme,Steel,1.5,24,100,2025-09-25,2\nSO-2002,FlowCore,Aluminum,2.0,36,60,2025-09-28,3`;

function parseOrdersCsv(csv: string): Order[] {
  const res = Papa.parse(csv, { header: true, skipEmptyLines: true });
  return (res.data as any[]).map((r, i) => ({
    id: r.id || `SO-${1000 + i}`,
    customer: r.customer || "Customer",
    material: r.material || "Steel",
    thickness: Number(r.thickness || 1),
    lengthInches: Number(r.lengthInches || 12),
    qty: Number(r.qty || 1),
    dueDate: r.dueDate || new Date().toISOString().slice(0,10),
    priority: Number(r.priority || 3),
  }));
}

function buildScheduleCsv(rows: ScheduledOrder[]): string {
  const header = ["machine","sequence","orderId","customer","material","thickness","lengthIn","qty","estSeconds"]; const lines = [header.join(",")];
  for (const r of rows) lines.push([r.machineId,r.sequenceIndex,r.id,r.customer,r.material,r.thickness,r.lengthInches,r.qty,r.estimatedSeconds].join(","));
  return lines.join("\n");
}

function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

// ================================= UI =================================
export default function Page() {
  const todayISO = new Date().toISOString().slice(0,10);

  const [machines] = useState<Machine[]>(REAL_MACHINES);
  const [employees, setEmployees] = useState<Employee[]>(STARTER_EMPLOYEES);
  const [ordersCsv, setOrdersCsv] = useState(ORDERS_CSV_TEMPLATE);
  const [orders, setOrders] = useState<Order[]>(parseOrdersCsv(ORDERS_CSV_TEMPLATE));
  const [shift, setShift] = useState<Shift>("A");
  const [strategy, setStrategy] = useState<Strategy>("changeover");
  const [planningDate, setPlanningDate] = useState<string>(todayISO);
  const [shiftConfig, setShiftConfig] = useState<typeof DEFAULT_SHIFT_CONFIG>(DEFAULT_SHIFT_CONFIG);
  const [clipToShift, setClipToShift] = useState<boolean>(false);
  const [carryToNextShift, setCarryToNextShift] = useState<boolean>(true);
  const [standards] = useState<CutStandard[]>(STARTER_STANDARDS);
  const [bladeSpeeds] = useState<BladeSpeedStandard[]>(STARTER_BLADE_SPEEDS);
  // Manual assignment controls
  const [manualMode, setManualMode] = useState<boolean>(false);
  const [manualUnassign, setManualUnassign] = useState<Record<string, string[]>>({});
  const [manualAdds, setManualAdds] = useState<Record<string, string[]>>({});

  const scheduled = useMemo(() => planOrders(orders, machines, standards, shift, strategy, bladeSpeeds, true), [orders, machines, standards, shift, strategy, bladeSpeeds]);
  const scheduledWithTimes = useMemo(() => addStartFinishTimes(scheduled, shift, planningDate, shiftConfig, clipToShift, carryToNextShift), [scheduled, shift, planningDate, shiftConfig, clipToShift, carryToNextShift]);
  const assigned = useMemo(() => autoAssignWorkforce(machines, employees, shift, todayISO), [machines, employees, shift, todayISO]);
  const assignedEffective = useMemo(() => {
    const out: Record<string, string[]> = {};
    Object.keys(assigned).forEach(mid => {
      const blocked = new Set(manualUnassign[mid] || []);
      const base = (assigned[mid] || []).filter(eid => !blocked.has(eid));
      const adds = (manualAdds[mid] || []);
      const uniq = Array.from(new Set([...base, ...adds]));
      out[mid] = uniq;
    });
    return out;
  }, [assigned, manualUnassign, manualAdds]);

  const handleUnassign = (empId: string, machineId: string) => {
    setManualUnassign(prev => {
      const set = new Set([...(prev[machineId] || [])]);
      set.add(empId);
      return { ...prev, [machineId]: Array.from(set) };
    });
  };

  # Counters used for add-eligibility (band/non-band limits)
  const counters = useMemo(() => {
    const band: Record<string, number> = {};
    const nonBand: Record<string, number> = {};
    const byId: Record<string, Machine> = Object.fromEntries(machines.map(m=>[m.id,m]));
    const add = (empId: string, mId: string) => {
      const m = byId[mId]; if (!m) return;
      if (isBandSaw(m)) band[empId] = (band[empId]||0)+1; else nonBand[empId] = (nonBand[empId]||0)+1;
    };
    Object.entries(assignedEffective).forEach(([mid, arr]) => arr.forEach(eid => add(eid, mid)));
    Object.entries(manualAdds).forEach(([mid, arr]) => arr.forEach(eid => add(eid, mid)));
    return { band, nonBand };
  }, [assignedEffective, manualAdds, machines]);

  const eligibleToAdd = (m: Machine): Employee[] => {
    const need = m.headcountByShift[shift] || 0;
    const have = (assignedEffective[m.id]||[]).length + (manualAdds[m.id]?.length||0);
    if (have >= need) return [];
    return employees.filter(e => {
      const okShift = (e.lockedShift ? e.lockedShift === shift : e.shift === shift);
      if (!okShift) return false;
      if (!isQualified(e, m, todayISO)) return false;
      const b = counters.band[e.id] || 0;
      const nb = counters.nonBand[e.id] || 0;
      if (isBandSaw(m)) return nb === 0 && b < 2;
      return b === 0 && nb === 0;
    });
  };

  const handleAdd = (empId: string, machineId: string) => {
    if (!empId) return;
    const m = machines.find(x=>x.id===machineId);
    if (!m) return;
    const need = m.headcountByShift[shift] || 0;
    const have = (assignedEffective[m.id]||[]).length + (manualAdds[m.id]?.length||0);
    if (have >= need) return; // headcount cap
    const b = counters.band[empId] || 0;
    const nb = counters.nonBand[empId] || 0;
    if ((isBandSaw(m) && (nb !== 0 || b >= 2)) || (!isBandSaw(m) && (b !== 0 || nb !== 0))) return;
    setManualAdds(prev => {
      const set = new Set([...(prev[machineId] || [])]);
      set.add(empId);
      return { ...prev, [machineId]: Array.from(set) };
    });
  };

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-semibold">Phoenix Sawing Operations Dashboard</h1>

      <Card>
        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <div className="text-xs font-medium">Shift</div>
            <Select value={shift} onValueChange={(v: any)=> setShift(v as Shift)}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select shift"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="A">A</SelectItem>
                <SelectItem value="B">B</SelectItem>
                <SelectItem value="C">C</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <div className="text-xs font-medium">Scheduling Strategy</div>
            <Select value={strategy} onValueChange={(v:any)=> setStrategy(v as Strategy)}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Choose"/></SelectTrigger>
              <SelectContent>
                <SelectItem value="changeover">Min Changeovers</SelectItem>
                <SelectItem value="material">Group by Material</SelectItem>
                <SelectItem value="size">Group by Size</SelectItem>
                <SelectItem value="due">Soonest Due</SelectItem>
                <SelectItem value="priority">Highest Priority</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2 grid grid-cols-2 gap-3 items-end">
            <div>
              <div className="text-xs font-medium">Planning Date</div>
              <input type="date" className="mt-1 w-full border rounded p-2 text-sm" value={planningDate} onChange={(e)=> setPlanningDate(e.target.value)} />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs font-medium flex-1">Clip at end of shift</label>
              <input type="checkbox" className="h-4 w-4" checked={clipToShift} onChange={(e)=> setClipToShift(e.target.checked)} />
            </div>
            <div className="col-span-2 grid grid-cols-3 gap-2">
              <div>
                <div className="text-xs">Shift {shift} Start (HH:MM)</div>
                <div className="flex gap-2 mt-1">
                  <input type="number" min={0} max={23} value={shiftConfig[shift].startHour} onChange={(e)=> setShiftConfig(sc=>({...sc, [shift]: {...sc[shift], startHour: Math.max(0, Math.min(23, Number(e.target.value)||0))}}))} className="w-20 border rounded p-1 text-sm" />
                  <input type="number" min={0} max={59} value={shiftConfig[shift].startMin} onChange={(e)=> setShiftConfig(sc=>({...sc, [shift]: {...sc[shift], startMin: Math.max(0, Math.min(59, Number(e.target.value)||0))}}))} className="w-20 border rounded p-1 text-sm" />
                </div>
              </div>
              <div>
                <div className="text-xs">Shift {shift} Length (min)</div>
                <input type="number" min={60} step={15} value={shiftConfig[shift].durationMin} onChange={(e)=> setShiftConfig(sc=>({...sc, [shift]: {...sc[shift], durationMin: Math.max(60, Number(e.target.value)||480)}}))} className="mt-1 w-full border rounded p-1 text-sm" />
              </div>
              <div>
                <div className="text-xs">Lunch Start (HH:MM)</div>
                <div className="flex gap-2 mt-1">
                  <input type="number" min={0} max={23} value={shiftConfig[shift].lunchStartHour} onChange={(e)=> setShiftConfig(sc=>({...sc, [shift]: {...sc[shift], lunchStartHour: Math.max(0, Math.min(23, Number(e.target.value)||0))}}))} className="w-20 border rounded p-1 text-sm" />
                  <input type="number" min={0} max={59} value={shiftConfig[shift].lunchStartMin} onChange={(e)=> setShiftConfig(sc=>({...sc, [shift]: {...sc[shift], lunchStartMin: Math.max(0, Math.min(59, Number(e.target.value)||0))}}))} className="w-20 border rounded p-1 text-sm" />
                </div>
              </div>
              <div>
                <div className="text-xs">Lunch (min)</div>
                <input type="number" min={0} step={5} value={shiftConfig[shift].lunchMinutes} onChange={(e)=> setShiftConfig(sc=>({...sc, [shift]: {...sc[shift], lunchMinutes: Math.max(0, Number(e.target.value)||0)}}))} className="mt-1 w-full border rounded p-1 text-sm" />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <label className="text-xs font-medium flex items-center gap-2"><input type="checkbox" className="h-4 w-4" checked={carryToNextShift} onChange={(e)=> setCarryToNextShift(e.target.checked)} /> Carry overflow to next shift</label>
            </div>
            <div className="flex items-center gap-4">
              <label className="text-xs font-medium flex items-center gap-2"><input type="checkbox" className="h-4 w-4" checked={manualMode} onChange={(e)=> setManualMode(e.target.checked)} /> Manual Assign mode</label>
              <Button variant="secondary" onClick={()=> { setManualUnassign({}); setManualAdds({}); }} disabled={!Object.keys(manualUnassign).length && !Object.keys(manualAdds).length}>Reset Manual Changes</Button>
            </div>
            <div className="flex items-end gap-2">
              <Button onClick={()=> setOrders(parseOrdersCsv(ordersCsv))}>Parse Orders</Button>
              <Button variant="secondary" onClick={()=> downloadText("machine_schedules.csv", buildScheduleCsv(scheduled))}>Export Schedule CSV</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="orders">
        <TabsList>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="machines">Machines</TabsTrigger>
          <TabsTrigger value="employees">Employees</TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          <Card>
            <CardContent className="p-4 space-y-3">
              <div>
                <div className="text-sm font-medium">Orders CSV</div>
                <textarea value={ordersCsv} onChange={(e)=> setOrdersCsv(e.target.value)} className="mt-1 w-full h-32 border rounded p-2 text-sm" />
              </div>
              <div className="overflow-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-2 py-1 text-left">Machine</th>
                      <th className="px-2 py-1 text-left">Seq</th>
                      <th className="px-2 py-1 text-left">Order</th>
                      <th className="px-2 py-1 text-left">Customer</th>
                      <th className="px-2 py-1 text-left">Material</th>
                      <th className="px-2 py-1 text-left">Thk/Dia</th>
                      <th className="px-2 py-1 text-left">Len (in)</th>
                      <th className="px-2 py-1 text-left">Qty</th>
                      <th className="px-2 py-1 text-left">Start</th>
                      <th className="px-2 py-1 text-left">Finish</th>
                      <th className="px-2 py-1 text-left">Est</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scheduledWithTimes.map(row => (
                      <tr key={`${row.machineId}-${row.sequenceIndex}-${row.id}`} className="border-t">
                        <td className="px-2 py-1">{row.machineId}</td>
                        <td className="px-2 py-1">{row.sequenceIndex}</td>
                        <td className="px-2 py-1">{row.id}</td>
                        <td className="px-2 py-1">{row.customer}</td>
                        <td className="px-2 py-1">{row.material}</td>
                        <td className="px-2 py-1">{row.thickness}</td>
                        <td className="px-2 py-1">{row.lengthInches}</td>
                        <td className="px-2 py-1">{row.qty}</td>
                        <td className="px-2 py-1">{formatTimeLocal(row.startISO)}</td>
                        <td className="px-2 py-1">{formatTimeLocal(row.endISO)}</td>
                        <td className="px-2 py-1">{formatSeconds(row.estimatedSeconds)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="machines">
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                {machines.filter(m=>m.department!=="Support" && m.department!=="Other").map(m => (
                  <div key={m.id} className="border rounded p-3">
                    <div className="font-medium">{m.name}</div>
                    <div className="text-xs text-gray-600">
                      {m.id} · {m.department} · Headcount need: {m.headcountByShift[shift]||0}
                      {(() => {
                        const need = m.headcountByShift[shift]||0;
                        const have = (assignedEffective[m.id]||[]).length;
                        if (!need) return null;
                        if (have < need) return <span className="ml-2 text-amber-700">(Under by {need - have})</span>;
                        if (have > need) return <span className="ml-2 text-red-700">(Over by {have - need})</span>;
                        return <span className="ml-2 text-green-700">(At headcount)</span>;
                      })()}
                    </div>
                    <div className="mt-2 text-xs">Assigned:</div>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {(assignedEffective[m.id]||[]).map(empId => {
                        const emp = employees.find(e=>e.id===empId);
                        const warn = emp?.certifications.some(c=>!isCertValid(emp!, c, todayISO));
                        return (
                          <div key={empId} className="inline-flex items-center gap-1">
                            <Badge variant={warn?"destructive":"secondary"}>{emp?.name || empId}{warn?" (cert exp)":""}</Badge>
                            {manualMode && (
                              <button aria-label="Unassign" className="ml-1 text-[10px] px-1 py-0.5 rounded bg-red-600 text-white" onClick={()=> handleUnassign(empId, m.id)}>×</button>
                            )}
                          </div>
                        );
                      })}
                      {!(assignedEffective[m.id]||[]).length && <Badge variant="outline">—</Badge>}
                    </div>
                    {manualMode && (
                      <div className="mt-2 flex items-center gap-2">
                        <select
                          className="border rounded p-1 text-xs"
                          value=""
                          onChange={(e)=> handleAdd(e.target.value, m.id)}
                          disabled={(m.headcountByShift[shift]||0) <= ((assignedEffective[m.id]||[]).length + (manualAdds[m.id]?.length||0))}
                        >
                          <option value="">{(m.headcountByShift[shift]||0) <= ((assignedEffective[m.id]||[]).length + (manualAdds[m.id]?.length||0)) ? 'At headcount' : 'Add operator…'}</option>
                          {eligibleToAdd(m).map(emp => (
                            <option key={emp.id} value={emp.id}>{emp.name}</option>
                          ))}
                        </select>
                        {!!(manualAdds[m.id]?.length) && (
                          <Button variant="secondary" className="!px-2 !py-1" onClick={()=> setManualAdds(prev=>({ ...prev, [m.id]: [] }))}>Clear adds</Button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employees">
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="overflow-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-2 py-1 text-left">Employee</th>
                      <th className="px-2 py-1 text-left">Shift</th>
                      <th className="px-2 py-1 text-left">Can Operate</th>
                      <th className="px-2 py-1 text-left">Certifications</th>
                    </tr>
                  </thead>
                  <tbody>
                    {employees.map(e => (
                      <tr key={e.id} className="border-t">
                        <td className="px-2 py-1">{e.name}</td>
                        <td className="px-2 py-1">{e.lockedShift ?? e.shift}</td>
                        <td className="px-2 py-1">{(e.canOperate||[]).join(', ') || '—'}</td>
                        <td className="px-2 py-1">{e.certifications.join(', ')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
