import React from 'react';
export const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default'|'secondary' }>
  = ({ variant='default', className='', ...props }) => (
  <button
    {...props}
    className={(variant==='secondary'
      ? 'bg-gray-200 hover:bg-gray-300 text-gray-900 '
      : 'bg-blue-600 hover:bg-blue-700 text-white ') +
      'px-3 py-1.5 rounded ' + className}
  />
);
