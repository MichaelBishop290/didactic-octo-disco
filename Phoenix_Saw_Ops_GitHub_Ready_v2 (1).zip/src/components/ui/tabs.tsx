'use client'
import React, { createContext, useContext, useState } from 'react';
type Ctx = { value: string; setValue: (v:string)=>void }
const TabsCtx = createContext<Ctx|null>(null);
export const Tabs: React.FC<{defaultValue: string; children: React.ReactNode}> = ({ defaultValue, children }) => {
  const [value, setValue] = useState(defaultValue);
  return <TabsCtx.Provider value={{ value, setValue }}><div>{children}</div></TabsCtx.Provider>;
};
export const TabsList: React.FC<{children: React.ReactNode}> = ({ children }) => (
  <div className="flex gap-2 border-b pb-2 mb-2">{children}</div>
);
export const TabsTrigger: React.FC<{value: string; children: React.ReactNode}> = ({ value, children }) => {
  const ctx = useContext(TabsCtx)!;
  const active = ctx.value === value;
  return (
    <button onClick={()=>ctx.setValue(value)} className={(active?'bg-blue-600 text-white':'bg-gray-200')+' px-3 py-1 rounded'}>{children}</button>
  );
};
export const TabsContent: React.FC<{value: string; children: React.ReactNode}> = ({ value, children }) => {
  const ctx = useContext(TabsCtx)!;
  if (ctx.value !== value) return null;
  return <div className="mt-2">{children}</div>;
};
