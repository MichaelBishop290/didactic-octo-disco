'use client'
import React, { createContext, useContext, useMemo } from 'react';

type Item = { value: string; label: React.ReactNode };
const Ctx = createContext<{ items: Item[]; value?: string; onChange?: (v:string)=>void }|null>(null);

export const Select: React.FC<{ value?: string; onValueChange?: (v:string)=>void; children: React.ReactNode }>
  = ({ value, onValueChange, children }) => {
  const items: Item[] = [];
  const walk = (nodes: any) => {
    React.Children.forEach(nodes, (child: any)=>{
      if (!child) return;
      if (child.type && child.type.displayName === 'SelectItem' && child.props?.value) {
        items.push({ value: String(child.props.value), label: child.props.children });
      } else if (child.props && child.props.children) {
        walk(child.props.children);
      }
    });
  };
  walk(children);
  const ctxVal = useMemo(()=>({ items, value, onChange: onValueChange }), [items, value, onValueChange]);
  return <Ctx.Provider value={ctxVal}><div className="w-full">{children}</div></Ctx.Provider>;
};

export const SelectTrigger: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className='', ...rest }) => {
  const ctx = useContext(Ctx)!;
  return (
    <select
      className={(className||'') + ' border rounded p-2 text-sm w-full'}
      value={ctx.value}
      onChange={(e)=> ctx.onChange?.(e.target.value)}
      {...rest as any}
    >
      {ctx.items.map(it=>(<option key={it.value} value={it.value}>{typeof it.label==='string'?it.label:it.value}</option>))}
    </select>
  );
};
export const SelectContent: React.FC<{children: React.ReactNode}> = ({ children }) => <>{children}</>;
const SI: React.FC<{ value: string; children: React.ReactNode }> = () => null;
SI.displayName = 'SelectItem';
export const SelectItem = SI;
export const SelectValue: React.FC<{ placeholder?: string }> = ({ placeholder }) => <span className="sr-only">{placeholder||''}</span>;
