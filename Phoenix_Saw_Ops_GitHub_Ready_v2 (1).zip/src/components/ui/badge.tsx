import React from 'react';
export const Badge: React.FC<{children: React.ReactNode; variant?: 'secondary'|'destructive'|'outline' }>
  = ({ children, variant='secondary' }) => (
  <span className={
    'inline-block text-xs rounded px-2 py-1 ' +
    (variant==='destructive' ? 'bg-red-100 text-red-800 border border-red-200' :
     variant==='outline' ? 'border border-gray-300 text-gray-700' :
     'bg-gray-100 text-gray-800')
  }>{children}</span>
);
