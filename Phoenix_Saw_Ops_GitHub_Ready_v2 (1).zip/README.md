# Phoenix Sawing Operations Dashboard (GitHub-ready)

## Run locally
```bash
npm i    # or: yarn / pnpm
npm run dev
# open http://localhost:3000
```

## Deploy to Vercel
1. Push this folder to a **new GitHub repo**.
2. In **vercel.com → New Project**, import the repo and deploy.
   - Build: `next build`
   - Output: `.next` (auto)

## Notes
- UI shims live in `src/components/ui/` to keep dependencies light.
- Your current dashboard is in `src/app/page.tsx` (client component).
